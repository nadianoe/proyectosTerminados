package webapp.webapp;

import app.web.WebappApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = WebappApplication.class)
class WebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
