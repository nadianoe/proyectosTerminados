
import java.util.Calendar;
import java.util.Date;

public class Fecha {

    private int dia;
    private int mes;
    private int anio;

    public Fecha(){
        this.setearFechaDelDia();
    }

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public Fecha(String fechaConFormatoString){
        System.out.println(fechaConFormatoString);
        String anio = fechaConFormatoString.substring(0,4);
        System.out.println(anio);
        this.anio = Integer.parseInt(anio);
        String mes = fechaConFormatoString.substring(5,7);
        System.out.println(mes);
        this.mes = Integer.parseInt(mes);
        String dia = fechaConFormatoString.substring(8,10);
        System.out.println(dia);
        this.dia = Integer.parseInt(dia);
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public void setearFechaDelDia(){
        Date fechaDelDia = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaDelDia);
        this.dia = calendar.get(Calendar.DAY_OF_MONTH);
        this.mes = calendar.get(Calendar.MONTH) + 1;
        this.anio = calendar.get(Calendar.YEAR);
    }


    public void imprimirFechaDelDia(){
        System.out.println(this.anio + "-" + this.mes + "-" + this.dia);
    }

    public String toString(){
        String fecha = this.anio + "-" + this.mes + "-" + this.dia;
        return fecha;
    }

    public static int calcularAnioActual(){
        java.util.Date fechaDelDia = new java.util.Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaDelDia);
        int anioActual = calendar.get(Calendar.YEAR);
        return anioActual;
    }

    public static int ANIO_ACTUAL = Fecha.calcularAnioActual();

    public static String fechaPorDefecto(){
        Fecha fechaPorDefecto = new Fecha(1,1,Fecha.ANIO_ACTUAL);
        String fecha = fechaPorDefecto.toString();
        return fecha;
    }
}
