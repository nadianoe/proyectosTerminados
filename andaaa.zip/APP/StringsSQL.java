public class StringsSQL {

}
