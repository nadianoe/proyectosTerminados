
import com.sun.corba.se.impl.orbutil.graph.Graph;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.text.AttributedCharacterIterator;

public class SistemaHostel {

    private AccesoABaseDeDatos acceso;
    private JFrame ventanaPrincipal;
    private JPanel autenticacion;
    private JPanel menu;
    private Form formulario;
    private JPanel buscar;

    public SistemaHostel(AccesoABaseDeDatos acceso, String tituloDeVentana){
        this.acceso = acceso;
        this.armarVentanaPrincipal(tituloDeVentana);
    }

    public SistemaHostel(AccesoABaseDeDatos acceso, JFrame ventanaPrincipal) {
        this.acceso = acceso;
        this.ventanaPrincipal = ventanaPrincipal;
    }

    public void agregarOpcionesNacionalidad(JPanel panel){
        JComboBox opcionesNacionalidades = new JComboBox();
        String nacionalidades[] = new String[]{"Argentina","Brasil","etc"};
        opcionesNacionalidades.setModel(new DefaultComboBoxModel(nacionalidades));
        String nacionalidadElegida = opcionesNacionalidades.getSelectedItem().toString();
        opcionesNacionalidades.setSelectedItem(nacionalidadElegida);
        panel.add(opcionesNacionalidades);
    }

    public void armarMenu() {

        this.menu = new JPanel();
        this.menu.setLayout(new BorderLayout());

        JPanel seccionImagen = new JPanel(new BorderLayout());

        //BufferedImage myPicture = ImageIO.read(new File("/home/alumno/Escritorio/logoAtahuallpa.png"));
        String pathToImage = "/home/alumno/Escritorio/imagenPrincipal.png";
        ImageIcon imagen = new ImageIcon(pathToImage);
        JLabel picLabel = new JLabel(imagen);
        seccionImagen.add("Center",picLabel);
        this.menu.add("North",seccionImagen);

        JPanel seccionBotones = new JPanel(new GridLayout(2,1));
        JButton botonFormulario = new JButton("INGRESAR NUEVO HUESPED");
        seccionBotones.add(botonFormulario);

        botonFormulario.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseReleased(MouseEvent e) {
                armarFormulario();
                ventanaPrincipal.add("Center",formulario);
                //Dimension ventanaMaximizada = ventanaPrincipal.getToolkit().getScreenSize();
                //ventanaPrincipal.setSize(ventanaMaximizada);
                ventanaPrincipal.setExtendedState(JFrame.MAXIMIZED_BOTH);


                //ventanaPrincipal.setResizable(true);
                ocultarMenu();
                mostrarFormulario();
            }
        });



        JButton botonBuscar = new JButton("BUSCAR INFORMACIÓN DE HUESPED");
        seccionBotones.add(botonBuscar);

        botonBuscar.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseReleased(MouseEvent e) {
                menu.setVisible(false);
            }
        });

        //this.menu.add("Center",seccionImagen);
        this.menu.add("Center",seccionBotones);
        ventanaPrincipal.add("Center",menu);

    }

    public void mostrarAutenticacion() {
        this.autenticacion.setVisible(true);
    }

    public void ocultarAutenticacion() {
        this.autenticacion.setVisible(false);
    }

    public void mostrarMenu() {
        this.menu.setVisible(true);
    }

    public void ocultarMenu() {
        this.menu.setVisible(false);
    }

    public void mostrarFormulario() {
        this.formulario.setVisible(true);
    }

    public void ocultarFormulario() {
        this.formulario.setVisible(false);
    }

    public void armarFormulario() {

        this.formulario = new Form();
        this.formulario.setLayout(new GridLayout(3, 2));

        JLabel cartelNombre = new JLabel("Nombre:");
        JTextField campoNombre = new JTextField();
        this.formulario.add(cartelNombre);
        this.formulario.add(campoNombre);

        JLabel cartelEdad = new JLabel("Edad:");
        JTextField campoEdad = new JTextField();
        this.formulario.add(cartelEdad);
        this.formulario.add(campoEdad);

        JButton guardar = new JButton("Guardar");
        this.formulario.add(guardar);

        guardar.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseReleased(MouseEvent e) {
                int edad = Integer.parseInt(campoEdad.getText());
                acceso.insertar(campoNombre.getText(),edad);
                campoNombre.setText("");
                campoEdad.setText("");
            }

        });

        JButton botonMenu = new JButton("Menu");
        this.formulario.add(botonMenu);

        botonMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                formulario.setVisible(false);
                menu.setVisible(true);
            }
        });
    }

    public void armarBuscar(){

    }

    public void mostrarBuscar() {

    }

    public void armarVentanaPrincipal(String tituloDeVentana){
        this.ventanaPrincipal = new JFrame(tituloDeVentana);
        this.ventanaPrincipal.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.ventanaPrincipal.setSize(800,800);
        this.ventanaPrincipal.setLayout(new BorderLayout());
        this.armarFormulario();
        this.armarMenu();
        this.armarAutenticacion();
    }

    public void iniciar() {
        this.ventanaPrincipal.setVisible(true);

    }



    private void armarAutenticacion() {
        autenticacion = new JPanel();
        autenticacion.setLayout(new GridLayout(3,2));

        JLabel cartelUser = new JLabel("usuario");
        JTextField campoUser = new JTextField();
        cartelUser.setLabelFor(campoUser);
        autenticacion.add(cartelUser);
        autenticacion.add(campoUser);

        JLabel cartelPass = new JLabel("constraseña");
        final JPasswordField campoPass = new JPasswordField();
        cartelPass.setLabelFor(campoPass);
        autenticacion.add(cartelPass);
        autenticacion.add(campoPass);

        JButton salir = new JButton("Salir");
        autenticacion.add(salir);
        salir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                ventanaPrincipal.dispose();
            }
        });

        JButton ingresar = new JButton("Ingresar");
        autenticacion.add(ingresar);
        ingresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {

                String username = campoUser.getText();
                String password = new String(campoPass.getPassword());
                acceso.conectar(username,password);

                ventanaPrincipal.add("Center",menu);
                ventanaPrincipal.setExtendedState(JFrame.MAXIMIZED_BOTH);
                ventanaPrincipal.setResizable(false);
                ocultarAutenticacion();
                mostrarMenu();
            }
        });

        this.ventanaPrincipal.add("Center",autenticacion);
    }

    public static void main(String args[]) {

        AccesoABaseDeDatos acceso = new AccesoABaseDeDatos("personas","alumnos");
        SistemaHostel app = new SistemaHostel(acceso,"app prueba");
        app.iniciar();
    }

}
