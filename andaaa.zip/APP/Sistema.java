
import javax.swing.*;
import java.awt.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

public class Sistema extends JFrame{

    private long cantidadDeRegistrosRealizados;
    private AccesoABaseDeDatos acceso;
    private Panel menu;
    private Form formulario;
    private Buscador buscador;

    public Sistema(AccesoABaseDeDatos acceso, String tituloDeVentana){

        this.setLayout(new BorderLayout());
        this.acceso = acceso;
        this.acceso.conectar("root","Pass_123");
        this.cantidadDeRegistrosRealizados = acceso.obtenerCantidadDeRegistros();
        System.out.println(cantidadDeRegistrosRealizados);
        this.menu = new Panel();
        this.formulario = new Form();

        MouseAdapter eventoBotonBuscar = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                String nombresIngresados = buscador.obtenerDatoSegunLabel("nombres");
                String apellidosIngresados = buscador.obtenerDatoSegunLabel("apellidos");
                buscador.limpiarCampos();
                Lista<String> campos = formulario.obtenerTodosLosCampos();
                Lista<Huesped> huespedes = acceso.obtenerElementosDeBase(campos,nombresIngresados,apellidosIngresados);
                buscador.setElementos(huespedes);
                buscador.actualizarLista(huespedes);

            }
        };

        MouseAdapter eventoBotonModificar = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int indexHuesped = buscador.getHuespedesEncontrados().getSelectedIndex();
                Huesped huespedElegido = buscador.getElementos().get(indexHuesped);
                formulario.llenarFormulario(huespedElegido);

                formulario.cambiarEventoABotonGuardar(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        Lista<Dato> datosActualizados = formulario.obtenerTodosLosValoresIngresados();
                        acceso.actualizarDatos(datosActualizados);
                        soloMostrarBuscar();

                    }
                });
                irAlFormulario();
            }
        };

        Lista<String> campos = this.formulario.obtenerTodosLosCampos();
        Lista<Huesped> huespedes = acceso.getDatosDeTodosLosHuespedes(campos);
        this.buscador = new Buscador(huespedes,eventoBotonModificar,eventoBotonBuscar);
        this.armarBuscador();
        this.setTitle(tituloDeVentana);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.armarVentanaPrincipal();
    }

    public Sistema(AccesoABaseDeDatos acceso) {
        this.acceso = acceso;
    }

    public JButton agregarBotonConEvento(String nombreDeBoton,MouseAdapter evento){
        JButton boton = new JButton(nombreDeBoton);
        boton.addMouseListener(evento);
        this.add(boton);
        return boton;
    }

    public void armarMenu() {

        Panel seccionImagen = new Panel();

        String pathToImage = "/home/alumno/Escritorio/imagenInicio.png";
        seccionImagen.agregarImagenAlCentro(pathToImage);
        //this.menu.agregarComponenteAlNorte(seccionImagen);

        Panel seccionBotones = new Panel(2,1);

        seccionBotones.agregarBotonConEvento("REGISTRAR NUEVO HUESPED", new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                formulario = new Form();
                armarFormulario();
                irAlFormulario();
                //soloMostrarFormulario();
            }
        });


        seccionBotones.agregarBotonConEvento("BUSCAR INFORMACIÓN DE HUESPED", new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                Lista<String> campos = formulario.obtenerTodosLosCampos();
                Lista<Huesped> huespedes = acceso.getDatosDeTodosLosHuespedes(campos);
                buscador.setElementos(huespedes);
                soloMostrarBuscar();
                maximizarVentana();
            }
        });

        this.menu.agregarComponenteAlCentro(seccionBotones);
        this.agregarComponenteAlCentro(menu);

    }

    public void irAlFormulario(){
        soloMostrarFormulario();
        maximizarVentana();
    }

    public void soloMostrarMenu() {
        this.ocultarFormulario();
        this.ocultarBuscar();
        this.agregarComponenteAlCentro(this.menu);
        this.menu.setVisible(true);
    }

    public void armarFormulario(){
        this.formulario.agregarEventoABoton("MENÚ",new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                volverAlMenu();
            }
        });

        String registrar = "GUARDAR DATOS";
        this.formulario.agregarEventoABoton(registrar,new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                long nuevoId = cantidadDeRegistrosRealizados + 1;
                //Dato datoId = new Dato("id",nuevoId);
                formulario.setId(nuevoId);
                Lista<Dato> datosIngresados = formulario.obtenerTodosLosValoresIngresados();
                //datosIngresados.set(0,datoId);
                acceso.ingresarHuesped(datosIngresados);
                soloMostrarMenu();
                /*
                   Lista<Dato> datosActualizados = formulario.obtenerTodosLosValoresIngresados();
                   acceso.actualizarDatos(datosActualizados);
                */
            }
        });
    }

    public void volverAlMenu(){
        ocultarFormulario();
        achicarVentana();
        soloMostrarMenu();
    }

    private void agregarComponenteAlCentro(Panel componente) {
        this.add("Center",componente);
    }

    public void ocultarMenu() {
        this.menu.setVisible(false);
    }

    public void soloMostrarFormulario() {
        ocultarMenu();
        ocultarBuscar();
        this.agregarComponenteAlCentro(this.formulario);
        this.formulario.setVisible(true);
    }

    public void ocultarFormulario() {
        this.formulario.setVisible(false);
    }


    public void armarBuscador(){

        //Vector<FilaHuesped> elementos = this.buscador.obtenerElementosParaSeccion();
        //String nombres = buscador.obtenerValorIngresado("nombres");
        //String apellidos = buscador.obtenerValorIngresado("apellidos");

        this.buscador.agregarEventoABoton("MENÚ", new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                formulario = new Form();
                armarFormulario();
                volverAlMenu();
                Lista<String> campos = formulario.obtenerTodosLosCampos();
                Lista<Huesped> huespedes = acceso.getDatosDeTodosLosHuespedes(campos);
                buscador.actualizarLista(huespedes);
            }
        });


    }

    public void soloMostrarBuscar() {
        this.agregarComponenteAlCentro(this.buscador);
        ocultarMenu();
        ocultarFormulario();
        this.buscador.setVisible(true);
    }

    public void ocultarBuscar(){
        this.buscador.setVisible(false);
    }

    public void maximizarVentana(){
        Dimension ventanaMaximizada = getToolkit().getScreenSize();
        setSize(ventanaMaximizada);
    }

    public void achicarVentana(){
        this.setSize(550,800);
    }

    public void armarVentanaPrincipal(){
        this.armarMenu();
        soloMostrarMenu();
        this.achicarVentana();
        this.armarFormulario();
        this.armarBuscador();
    }

    public void iniciar() {
        this.setVisible(true);
        //this.acceso.conectar("root","Pass_123");
    }

    public void registrarNuevoHuespedEnBaseDeDatos(){

    }

    public static void main(String args[]) {
        AccesoABaseDeDatos acceso = new AccesoABaseDeDatos("atahualpaHostel","huespedes");
        Sistema app = new Sistema(acceso,"app prueba");
        app.iniciar();
    }
}