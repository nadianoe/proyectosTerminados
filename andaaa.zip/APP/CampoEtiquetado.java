
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.HashSet;

public class CampoEtiquetado extends Panel{

    private String nombreDeCampo;
    private JLabel etiqueta;
    private JTextField campoDeTexto;

    public CampoEtiquetado(String nombre, JLabel etiqueta) {
        super(1,2);
        this.setName(nombre);
        this.nombreDeCampo = nombre;
        this.etiqueta = etiqueta;
        this.campoDeTexto = new JTextField();
    }

    public CampoEtiquetado(String nombre, String valorEtiqueta){
        super(1,2);
        this.setName(nombre);
        this.etiqueta = new JLabel(valorEtiqueta);
        this.campoDeTexto = new JTextField();
    }

    public CampoEtiquetado(String nombre) {
        super(1,2);
        this.setLayout(null);
        this.setName(nombre);
        this.nombreDeCampo = nombre;
        this.etiqueta = new JLabel();
        this.etiqueta.setText(this.darFormatoDeEtiqueta(nombre));
        this.campoDeTexto = new JTextField("");
        this.add(etiqueta);
        this.add(campoDeTexto);
        this.setVisible(true);

        this.campoDeTexto.setFont(new Font("Arial", Font.PLAIN, 15));
        this.campoDeTexto.setSize(350,20);
        this.campoDeTexto.setLocation(200, 25);

        this.etiqueta.setFont(new Font("Arial", Font.PLAIN, 15));
        this.etiqueta.setSize(150, 20);
        this.etiqueta.setLocation(50, 25);
    }

    public JLabel getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(JLabel etiqueta) {
        this.etiqueta = etiqueta;
    }

    public JTextField getCampoDeTexto() {
        return campoDeTexto;
    }

    public void setCampoDeTexto(JTextField campoDeTexto) {
        this.campoDeTexto = campoDeTexto;
    }

    @Override
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();
        Object valorDeCampo = new Object();
        HashSet<String> camposConValoresNumericos = new HashSet<>();
        camposConValoresNumericos.add("telefono");
        camposConValoresNumericos.add("id");

        if (this.nombreDeCampo.contains("telefono") ||
            this.nombreDeCampo.equals("id")){
            valorDeCampo = Long.parseLong(this.campoDeTexto.getText());
        }else{
            valorDeCampo = this.campoDeTexto.getText();
        }

        Dato dato = new Dato(this.nombreDeCampo,valorDeCampo);
        datos.add(dato);
        return datos;
    }

    public String obtenerTextoIngresado(){
        String textoIngresado = this.campoDeTexto.getText();
        return textoIngresado;
    }

    @Override
    public void setValores(Huesped huesped) {
        HashMap<String,Object> valores = huesped.getDatosPersonales();
        Object valorRecibido = valores.get(this.nombreDeCampo);
        String nuevoValor = valorRecibido.toString();
        this.campoDeTexto.setText(nuevoValor);
    }

    public void setValorACampoDeTexto(Object valor){
        this.campoDeTexto.setText(valor.toString());
    }

    @Override
    public Lista<String> getNombresDeCampos() {
        Lista<String> nombresDeCampo = new Lista<>();
        nombresDeCampo.add(this.nombreDeCampo);
        return nombresDeCampo;
    }
}
