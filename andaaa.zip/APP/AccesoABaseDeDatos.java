
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class AccesoABaseDeDatos {

    private Connection conexion;
    private String nombreBaseDeDatos;
    private String nombreTabla;

    public AccesoABaseDeDatos(Connection conexion) {
        this.conexion = conexion;
    }

    public AccesoABaseDeDatos(Connection conexion, String nombreBaseDeDatos, String nombreTabla) {
        this.conexion = conexion;
        this.nombreBaseDeDatos = nombreBaseDeDatos;
        this.nombreTabla = nombreTabla;
    }

    public AccesoABaseDeDatos(String nombreBaseDeDatos, String nombreTabla) {
        this.nombreBaseDeDatos = nombreBaseDeDatos;
        this.nombreTabla = nombreTabla;
    }

    public void conectar(String user, String password) {

        String url = "jdbc:mysql://localhost:3306/" + this.nombreBaseDeDatos;

        try {

            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection(url, user, password);

            if (conexion != null) {
                JOptionPane.showMessageDialog(null, "Conectado a base de datos!");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo conectar :(");
            }

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public String obtenerConsulta(Lista<Dato> camposConValores){
        String consulta = "INSERT INTO " + this.nombreTabla + " ";

        String campos = "(";
        for (Dato dato : camposConValores){
            String nombreDeCampo = dato.getNombreDeCampo();
            campos = campos + nombreDeCampo + ",";
        }

        //campos = campos.substring(0,campos.length() - 2) + ")";
        campos = this.removerUltimoChar(campos) + ")";

        String valores = "(";
        for (Dato asociacion : camposConValores){
            Object valorRecibido = asociacion.getValor();
            String valorFormateado = this.agregarFormatoParaConsulta(valorRecibido);
            valores = valores + valorFormateado + ",";
        }
        //valores = valores.substring(0,campos.length() - 2);
        valores = this.removerUltimoChar(valores) + ")";
        consulta = consulta + campos + " " + "VALUES" + " " + valores + ";";

        return consulta;
    }

    public String removerUltimoChar(String string){
        String nuevoString = "";
        for (int i = 0; i < string.length() ; i++) {
            if (i != (string.length()-1) ) {
                nuevoString = nuevoString + string.charAt(i);
            }
        }
        return nuevoString;
    }

    public String agregarFormatoParaConsulta(Object valor){
        String valorConFormato = "";
        if (valor.getClass().equals(String.class)){
            valorConFormato = "\"" + valor + "\"";
        } else if (valor.getClass().equals(java.sql.Date.class)){
            valorConFormato = valor.toString();
        } else {
            valorConFormato = valor.toString();
        }

        return valorConFormato;
    }

    public void ingresarHuesped(Lista<Dato> camposConValores){
        String consulta = this.obtenerConsulta(camposConValores);
        System.out.println(consulta);
        Lista.imprimirLista(camposConValores);
        try {
            PreparedStatement sentenciaSQL = conexion.prepareStatement(consulta);
            int result = sentenciaSQL.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Persona guardada");
            } else {
                JOptionPane.showMessageDialog(null, "Error al cargar persona");
            }

            sentenciaSQL.close();
            //conexion.close();

        } catch (SQLException e){
            e.printStackTrace();
        }
    }



    public void actualizarDatos(Lista<Dato> camposConValores) {
        //String valor = (String) camposConValores.get(0).getValor();
        //System.out.println(valor);
        //long idHuesped = Long.parseLong(valor);
        long idHuesped = (long) camposConValores.get(0).getValor();
        String SQL = "UPDATE huespedes SET ";
        SQL +=  this.obtenerClavesConValores(camposConValores);
        SQL += " WHERE id = " + idHuesped + ";";
        System.out.println(SQL);

        Statement stmt = null;
        try {
            //stmt = conexion.createStatement();
            //int count = stmt.executeUpdate(SQL);
            //stmt.close();

            PreparedStatement sentenciaSQL = conexion.prepareStatement(SQL);
            int result = sentenciaSQL.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(null, "DATOS ACTUALIZADOS");
            } else {
                JOptionPane.showMessageDialog(null, "Error al ACTUALIZAR");
            }

            sentenciaSQL.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public long obtenerCantidadDeRegistros(){
        long cantidadDeRegistros = 0;
        String consulta = "SELECT COUNT(*) FROM " + this.nombreTabla + ";";
        try {

            Statement stmt = this.conexion.createStatement();
            ResultSet rs = stmt.executeQuery(consulta);

            while (rs.next()) {
                cantidadDeRegistros = (long) rs.getObject(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cantidadDeRegistros;
    }

    public String obtenerClavesConValores(Lista<Dato> camposConValores){
        String valoresConConsultas = "";
        for (Dato campoConValor : camposConValores) {
            String campo = campoConValor.getNombreDeCampo();
            Object valor = campoConValor.getValor();
            String valorFormateado = this.agregarFormatoParaConsulta(valor);
            valoresConConsultas += campo + " = " + valorFormateado + ",";
        }

        valoresConConsultas = removerUltimoChar(valoresConConsultas);

        return valoresConConsultas;
    }


    public Lista<Huesped> getDatosDeTodosLosHuespedes(Lista<String> nombresDeCampos) {
        String consulta = "SELECT * FROM huespedes";
        Lista<Huesped> huespedesEncontrados = new Lista<>();

        try {

            Statement stmt = this.conexion.createStatement();
            ResultSet rs = stmt.executeQuery(consulta);

            while (rs.next()) {

                Huesped huesped = new Huesped();
                HashMap<String,Object> datos = new HashMap<>();

                for (String nombreDeCampo : nombresDeCampos) {
                    Object valor = rs.getObject(nombreDeCampo);
                    datos.put(nombreDeCampo,valor);
                }

                huesped.setDatosPersonales(datos);
                huespedesEncontrados.add(huesped);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return huespedesEncontrados;
    }


    public ArrayList<String> obtenerPalabrasSeparadas(String palabras){
        ArrayList<String> palabrasSeparadas = new ArrayList<>();
        String unaPalabra = "";

        if(palabras.length() != 0) {
            for (int i = 0; i < palabras.length(); i++) {
                if (palabras.charAt(i) != ' '){
                    unaPalabra += palabras.charAt(i);
                } else {
                    palabrasSeparadas.add(unaPalabra);
                    unaPalabra = "";
                }

                if ( i == palabras.length()-1 &&
                        palabras.charAt(i) != ' '){
                    palabrasSeparadas.add(unaPalabra);
                }
            }
        }else{
            unaPalabra = "";
            palabrasSeparadas.add(unaPalabra);
        }
        return palabrasSeparadas;
    }

    public String quitarPrimerLetra(String palabra){
        String sinPrimerLetra = palabra.substring(1);
        return sinPrimerLetra;
    }

    public String obtenerValoresConComodin(String strings){
        String formatoParaConsulta = "";
        System.out.println();obtenerPalabrasSeparadas(strings);
        for (String string : obtenerPalabrasSeparadas(strings)) {
            formatoParaConsulta += "\"%"+ string + "%\" or ";
        }

        System.out.println(formatoParaConsulta);
        int size = formatoParaConsulta.length();
        formatoParaConsulta = formatoParaConsulta.substring(0,size-4);
        System.out.println(formatoParaConsulta);

        return formatoParaConsulta;
    }

    public Lista<Huesped> obtenerElementosDeBase(Lista<String> campos,String nombresABuscar, String apellidosABuscar){

        //select * from huespedes where upper(nombres) like "%%";
        //select * from huespedes where upper(nombres) like "%%" and upper(apellidos) like "%i%";
        //select * from huespedes where (upper(nombres) like "%a" or "%b%") and (upper(apellidos) like "%i%");
        
        String SQL = "SELECT * FROM huespedes where ";
        String nombresFormateados = this.obtenerValoresConComodin(nombresABuscar);
        SQL += "(UPPER(nombres) LIKE " + nombresFormateados + ")";
        String apellidosFormateados = this.obtenerValoresConComodin(apellidosABuscar);
        SQL += " and (UPPER(apellidos) LIKE " + apellidosFormateados + ");";

        System.out.println(SQL);

        Lista<Huesped> huespedesEncontrados = new Lista<>();
        HashMap<String,Object> datos = new HashMap<>();

        try {

            Statement stmt = this.conexion.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {

                Huesped huespedEncontrado = new Huesped();

                for (String campo : campos) {
                    Object valor = rs.getObject(campo);
                    datos.put(campo,valor);
                }

                huespedEncontrado.setDatosPersonales(datos);
                huespedesEncontrados.add(huespedEncontrado);

            }


            System.out.println(datos);
            System.out.println(huespedesEncontrados);


            rs.close();
            stmt.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return huespedesEncontrados;
    }



    public void insertar(String nombre, int edad)  {

        try {
            nombre = "\"" + nombre + "\"";
            String consulta = "INSERT INTO " + nombreTabla + " (nombre,edad) VALUES (" + nombre + "," + edad + ");";
            System.out.println(consulta);

            PreparedStatement sentenciaSQL = conexion.prepareStatement(consulta);

            int result = sentenciaSQL.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Persona guardada");
            } else {
                JOptionPane.showMessageDialog(null, "Error al cargar persona");
            }

            sentenciaSQL.close();
            //conexion.close();

        } catch (SQLException e){
            e.printStackTrace();
        }
    }



    public void cerrarConexion() {

        try {
            conexion.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
