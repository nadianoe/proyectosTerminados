
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.*;

public class Form extends PanelConBotones{

    private JLabel titulo;
    private Lista<Panel> elementos;
    private Lista<Dato> datosIngresados;

    public Form(){
        super(15,1);
        this.elementos = new Lista<>();

        this.agregarTituloDeSeccion("FORMULARIO DE ADMISIÓN",25);
        CampoEtiquetado id = new CampoEtiquetado("id");
        CampoEtiquetado nombres = new CampoEtiquetado("nombres");
        CampoEtiquetado apellidos = new CampoEtiquetado("apellidos");
        Bloque bloque1 = new Bloque(nombres,apellidos);
        this.elementos.add(id,nombres,apellidos);

        SelectorEtiquetado nacionalidad = new SelectorEtiquetado("nacionalidad",Selector.paises());
        SelectorFechaEtiquetada fechaDeNacimiento = new SelectorFechaEtiquetada("fechaDeNacimiento");
        Bloque bloque2 = new Bloque(nacionalidad,fechaDeNacimiento);
        this.elementos.add(nacionalidad,fechaDeNacimiento);

        CampoEtiquetado lugar = new CampoEtiquetado("lugar");
        SelectorConCampo tipoDeDocumento = new SelectorConCampo("tipoDeDocumento","numeroDeDocumento","DNI","PASAPORTE","OTROS");
        Bloque bloque3 = new Bloque(lugar,tipoDeDocumento);
        this.elementos.add(lugar,tipoDeDocumento);

        CampoEtiquetado domicilio = new CampoEtiquetado("domicilio");
        CampoEtiquetado ciudad = new CampoEtiquetado("ciudad");
        Bloque bloque4 = new Bloque(domicilio,ciudad);
        this.elementos.add(domicilio,ciudad);


        SelectorConCampo tipoDeLugar = new SelectorConCampo("tipoDeLugar","nombreDelLugar","PROVINCIA","DEPARTAMENTO");
        SelectorEtiquetado pais = new SelectorEtiquetado("pais",Selector.paises());
        Bloque bloque5 = new Bloque(tipoDeLugar,pais);
        this.elementos.add(tipoDeLugar,pais);

        this.agregarComponentes(bloque1,bloque2,bloque3,bloque4,bloque5);

        CampoEtiquetado telefono = new CampoEtiquetado("telefono");
        CampoEtiquetado email = new CampoEtiquetado("email");
        Bloque bloque6 = new Bloque(telefono,email);
        this.elementos.add(telefono,email);

        CampoEtiquetado nombreObraSocial = new CampoEtiquetado("obraSocial");
        Bloque bloque7 = new Bloque(nombreObraSocial);

        //this.agregarSubtituloDeSeccion("Obra social");
        CampoEtiquetado direccionObraSocial = new CampoEtiquetado("direccionObraSocial");
        CampoEtiquetado telefonoObraSocial = new CampoEtiquetado("telefonoObraSocial");
        Bloque bloque8 = new Bloque(direccionObraSocial,telefonoObraSocial);

        this.elementos.add(nombreObraSocial,direccionObraSocial,telefonoObraSocial);

        CampoEtiquetado trabajoEn = new CampoEtiquetado("trabajoEn");
        CampoEtiquetado empresa = new CampoEtiquetado("empresa");
        Bloque bloque9 = new Bloque(trabajoEn,empresa);

        CampoEtiquetado estudioEn = new CampoEtiquetado("estudioEn");
        CampoEtiquetado carrera = new CampoEtiquetado("carrera");
        Bloque bloque10 = new Bloque(estudioEn,carrera);

        this.elementos.add(trabajoEn,empresa,estudioEn,carrera);

        CampoEtiquetado realizoCursoDe = new CampoEtiquetado("realizoCursoDe");
        CampoEtiquetado cursoEn = new CampoEtiquetado("cursoEn");
        Bloque bloque11 = new Bloque(realizoCursoDe,cursoEn);

        this.agregarComponentes(bloque6,bloque7,bloque8,bloque9,bloque10,bloque11);

        this.agregarTituloDeSeccion("Tiempo de hospedaje",20);

        SelectorFechaEtiquetada desde = new SelectorFechaEtiquetada("fechaDesde");
        SelectorFechaEtiquetada hasta = new SelectorFechaEtiquetada("fechaHasta");
        Bloque bloque12 = new Bloque(desde,hasta);


        this.elementos.add(realizoCursoDe,cursoEn,desde,hasta);
/*
        JButton botonMenu = new JButton("MENÚ");
        JButton botonFormulario = new JButton("GUARDAR DATOS");
        Bloque bloque13 = new Bloque(botonMenu,botonFormulario);

*/
        this.agregarComponentes(bloque12);

        JButton botonMenu = new JButton("MENÚ");
        JButton botonFormulario = new JButton("GUARDAR DATOS");
        this.agregarSeccionBotones(botonMenu,botonFormulario);


    }

    public void setId(long value){
        for (Panel elemento : this.elementos) {
            if (elemento.getName().equals("id")){
                CampoEtiquetado campo = (CampoEtiquetado) elemento;
                campo.setValorACampoDeTexto(value);
                break;
            }
        }
    }


    public Form(int filas, int columnas, Lista<Panel> elementos) {
        super(filas, columnas);
        this.elementos = elementos;
    }

    public void cambiarEventoABotonGuardar(MouseAdapter evento){
        JButton botonNuevo = new JButton("ACTUALIZAR DATOS");
        botonNuevo.addMouseListener(evento);
        this.getSeccionBotones().remove(1);
        //this.getSeccionBotones().setComponentZOrder(botonNuevo,1);
        this.getSeccionBotones().add(botonNuevo);
    }

    public Lista<Panel> getElementos() {
        return elementos;
    }

    public void setElementos(Lista<Panel> elementos) {
        this.elementos = elementos;
    }

    public JLabel getTitulo() {
        return titulo;
    }

    public void setTitulo(JLabel titulo) {
        this.titulo = titulo;
    }

    public void agregarComponentes(Component... componentes){
        for (Component componente : componentes) {
            this.add(componente);
        }
    }

    public void agregarComponentes(Panel... componentes){
        for (Panel componente : componentes) {
            this.add(componente);
        }
    }

    public Component obtenerElementoDeDato(String nombreDeDato){
        Component elementoBuscado = null;
        for (Component elemento : this.elementos) {
            if (elemento.getName().equals(nombreDeDato)){
                elementoBuscado = elemento;
            }
        }
        return elementoBuscado;
    }
/*
    public JPanel agregarPanelesAlineados(String... nombresDeCampos){
        int cantidadDeComponentesPorLinea = nombresDeCampos.length;
        JPanel panelConFilaDeComponentes = new Panel(1,cantidadDeComponentesPorLinea);
        for (String nombreDeCampo : nombresDeCampos) {
            Elemento componente = obtenerElementoDeDato(nombreDeCampo);
            //panelConFilaDeComponentes.add();
        }
        return null;
    }
*/
    public void agregarCampo(String nombreDelCampo){
        JLabel cartel = new JLabel(nombreDelCampo);
        JTextField campo = new JTextField();
        campo.setName(nombreDelCampo);
        cartel.setLabelFor(campo);
        this.add(cartel);
        this.add(campo);
    }
/*
    public void crearCampo(String nombreDelCampo){
        JLabel cartel = new JLabel(nombreDelCampo);
        JTextField campo = new JTextField();
        campo.setName(nombreDelCampo);
        cartel.setLabelFor(campo);
        this.add(cartel);
        this.add(campo);
    }
    */

    public void agregarCamposAlineados(String... nombresDeCampos){
        int cantidadDeComponentesPorLinea = nombresDeCampos.length;
        Panel panelConFilaDeComponentes = new Panel(1,cantidadDeComponentesPorLinea);

        for (String nombreDeCampo : nombresDeCampos) {
            panelConFilaDeComponentes.agregarCampo(nombreDeCampo);
        }

        this.add(panelConFilaDeComponentes);
    }



    /*
    public JTextField obtenerCampoSegunNombre(String nombre){
        JTextField campo = new JTextField();
        for (Component component : this.getComponents()) {
            if (component.getName().equals(nombre)){
                campo = (JTextField)component;
            }
        }
        return campo;
    }

     */


    public JTextField obtenerCampoSegunNombre(String nombre){
        JTextField campo = new JTextField();
        for (Component component : this.getComponents()) {
            if (component.getName().equals(nombre)){
                campo = (JTextField)component;
            }
        }
        return campo;
    }

    public Object obtenerValorSegunNombre(String nombre) {
        JTextField campo = this.obtenerCampoSegunNombre(nombre);
        String valorIngresado = campo.getText();

        if (nombre.equals("DNI") || nombre.equals("TELÉFONO")) {
            int valor = Integer.parseInt(valorIngresado);
            return valor;
        }

        return valorIngresado;
    }

    public void agregarSelectorPais(String nombreDeCampo){
        Vector<String> opciones = this.getNacionalidades();
        this.agregarCampoConOpciones(nombreDeCampo,opciones);
    }

    /*
        public void agregarSelectorTipoDeDocumento(){
            Vector<String> opciones = new Vector<>(Arrays.asList("DNI","PASAPORTE","CÉDULA"));
            this.agregarCampoConOpciones("TIPO DE DOCUMENTO",opciones);
        }
    */
    public void agregarSelector(String... opcionesIngresadas){
        Vector opciones = new Vector<>(Arrays.asList(opcionesIngresadas));
        String nombreDeCampo = "";

        for (int i = 0; i < opcionesIngresadas.length; i++) {
            String opcionIngresada = opcionesIngresadas[i];
            opcionIngresada.toUpperCase();
            int ultimoIndice = opcionesIngresadas.length - 1;
            if (i != ultimoIndice){
                nombreDeCampo = nombreDeCampo + opcionIngresada + "/";
            }else{
                nombreDeCampo = nombreDeCampo + opcionIngresada;
            }
        }
        this.agregarCampoConOpciones(nombreDeCampo,opciones);
    }



    public void agregarCampoConOpciones(String nombreCampo, Vector<String> opciones){
        JComboBox campoOpciones = new JComboBox();
        campoOpciones.setModel(new DefaultComboBoxModel(opciones));
        String opcionElegida = campoOpciones.getSelectedItem().toString();
        campoOpciones.setSelectedItem(opcionElegida);
        campoOpciones.setName(opcionElegida);
        this.add(campoOpciones);
    }

    public Vector<String> getNacionalidades(){
        String naciones = "Afganistán," +
                "Albania," +
                "Alemania," +
                "Andorra," +
                "Angola," +
                "Antigua y Barbuda," +
                "Arabia Saudita," +
                "Argelia," +
                "Argentina," +
                "Armenia," +
                "Australia," +
                "Austria," +
                "Azerbaiyán," +
                "Bahamas," +
                "Bangladés," +
                "Barbados," +
                "Baréin," +
                "Bélgica," +
                "Belice," +
                "Benín," +
                "Bielorrusia," +
                "Birmania," +
                "Bolivia," +
                "Bosnia y Herzegovina," +
                "Botsuana," +
                "Brasil," +
                "Brunéi," +
                "Bulgaria," +
                "Burkina Faso," +
                "Burundi," +
                "Bután," +
                "Cabo Verde," +
                "Camboya," +
                "Camerún," +
                "Canadá," +
                "Catar," +
                "Chad," +
                "Chile," +
                "China," +
                "Chipre," +
                "Ciudad del Vaticano," +
                "Colombia," +
                "Comoras," +
                "Corea del Norte," +
                "Corea del Sur," +
                "Costa de Marfil," +
                "Costa Rica," +
                "Croacia," +
                "Cuba," +
                "Dinamarca," +
                "Dominica," +
                "Ecuador," +
                "Egipto," +
                "El Salvador," +
                "Emiratos Árabes Unidos," +
                "Eritrea," +
                "Eslovaquia," +
                "Eslovenia," +
                "España," +
                "Estados Unidos," +
                "Estonia," +
                "Etiopía," +
                "Filipinas," +
                "Finlandia," +
                "Fiyi," +
                "Francia," +
                "Gabón," +
                "Gambia," +
                "Georgia," +
                "Ghana," +
                "Granada," +
                "Grecia," +
                "Guatemala," +
                "Guyana," +
                "Guinea," +
                "Guinea ecuatorial," +
                "Guinea-Bisáu," +
                "Haití," +
                "Honduras," +
                "Hungría," +
                "India," +
                "Indonesia," +
                "Irak," +
                "Irán," +
                "Irlanda," +
                "Islandia," +
                "Islas Marshall," +
                "Islas Salomón," +
                "Israel," +
                "Italia," +
                "Jamaica," +
                "Japón," +
                "Jordania," +
                "Kazajistán," +
                "Kenia," +
                "Kirguistán," +
                "Kiribati," +
                "Kuwait," +
                "Laos," +
                "Lesoto," +
                "Letonia," +
                "Líbano," +
                "Liberia," +
                "Libia," +
                "Liechtenstein," +
                "Lituania," +
                "Luxemburgo," +
                "Macedonia del Norte," +
                "Madagascar," +
                "Malasia," +
                "Malaui," +
                "Maldivas," +
                "Malí," +
                "Malta," +
                "Marruecos," +
                "Mauricio," +
                "Mauritania," +
                "México," +
                "Micronesia," +
                "Moldavia," +
                "Mónaco," +
                "Mongolia," +
                "Montenegro," +
                "Mozambique," +
                "Namibia," +
                "Nauru," +
                "Nepal," +
                "Nicaragua," +
                "Níger," +
                "Nigeria," +
                "Noruega," +
                "Nueva Zelanda," +
                "Omán," +
                "Países Bajos," +
                "Pakistán," +
                "Palaos," +
                "Panamá," +
                "Papúa Nueva Guinea," +
                "Paraguay," +
                "Perú," +
                "Polonia," +
                "Portugal," +
                "Reino Unido," +
                "República Centroafricana," +
                "República Checa," +
                "República del Congo," +
                "República Democrática del Congo," +
                "República Dominicana," +
                "Ruanda," +
                "Rumanía," +
                "Rusia," +
                "Samoa," +
                "San Cristóbal y Nieves," +
                "San Marino," +
                "San Vicente y las Granadinas," +
                "Santa Lucía," +
                "Santo Tomé y Príncipe," +
                "Senegal," +
                "Serbia," +
                "Seychelles," +
                "Sierra Leona," +
                "Singapur," +
                "Siria," +
                "Somalia," +
                "Sri Lanka," +
                "Suazilandia," +
                "Sudáfrica," +
                "Sudán," +
                "Sudán del Sur," +
                "Suecia," +
                "Suiza," +
                "Surinam," +
                "Tailandia," +
                "Tanzania," +
                "Tayikistán," +
                "Timor Oriental," +
                "Togo," +
                "Tonga," +
                "Trinidad y Tobago," +
                "Túnez," +
                "Turkmenistán," +
                "Turquía," +
                "Tuvalu," +
                "Ucrania," +
                "Uganda," +
                "Uruguay," +
                "Uzbekistán," +
                "Vanuatu," +
                "Venezuela," +
                "Vietnam," +
                "Yemen," +
                "Yibuti," +
                "Zambia," +
                "Zimbabue,";

        Vector<String> nacionalidades = new Vector<>();
        String pais = "";

        for (int i = 0; i < naciones.length(); i++) {
            if (naciones.charAt(i) != ','){
                pais = pais + naciones.charAt(i);
            }else{
                nacionalidades.add(pais);
                pais = "";
            }
        }

        return nacionalidades;
    }

    public void agregarImagenAlCentro(String pathToImage){
        ImageIcon imagen = new ImageIcon(pathToImage);
        JLabel picLabel = new JLabel(imagen);
        this.add("Center",picLabel);
    }



    public Lista<Dato> obtenerTodosLosValoresIngresados(){
        
        Lista<Dato> camposConValores = new Lista<>();
       
        for (Panel elemento : this.elementos) {
            camposConValores.addAll(elemento.obtenerDatos());
        }
        return camposConValores;
    }

    public  Object obtenerValorSegunNombreDeCampo(String nombreDeCampo){
        Lista<Dato> camposConValores = this.obtenerTodosLosValoresIngresados();
        Object valorBuscado = new Object();
        for (Dato campoConValor : camposConValores) {
            if (campoConValor.getNombreDeCampo().equals(nombreDeCampo)){
                valorBuscado = campoConValor.getValor();
            }
        }
        return valorBuscado;
    }


    public Lista<String> obtenerTodosLosCampos(){
        Lista<String> campos = new Lista<>();

        for (Panel elemento : this.elementos) {
            campos.addAll(elemento.getNombresDeCampos());
        }
        /*
        Lista<Dato> datosIngresados = this.obtenerTodosLosValoresIngresados();
        for (Dato datoIngresado : datosIngresados) {
            String campo = datoIngresado.getNombreDeCampo();
            campos.add(campo);
        }
         */
        return campos;
    }

    public void llenarFormulario(Huesped huesped){
        for (Panel elemento : this.elementos) {
            elemento.setValores(huesped);
        }
    }

}
