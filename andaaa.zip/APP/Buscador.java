import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.Vector;

public class Buscador extends PanelConBotones {

    //private Form seccionCamposDeBusqueda;
    private Bloque seccionCamposDeBusqueda;
    private Lista<Huesped> elementos;
    private JList huespedesEncontrados;
    private JScrollPane seccionElementos;
    private MouseAdapter eventoBotonModificarDato;

    public Buscador(Lista<Huesped> huespedes,MouseAdapter eventoBotonModificar,MouseAdapter eventoBotonBuscar){
        super(6,1);

        this.elementos = huespedes;
        this.eventoBotonModificarDato = eventoBotonModificar;

        Vector<String> contenidoDeLista = this.obtenerInfoDeHuespedes();
        this.huespedesEncontrados = new JList(contenidoDeLista);
        this.seccionElementos = new JScrollPane(this.huespedesEncontrados);

        this.agregarTituloDeSeccion("BUSCAR INFORMACIÓN DE HUESPED",25);
        this.agregarTituloDeSeccion("Ingrese nombres y apellidos del huesped a buscar",20);

        CampoEtiquetado nombres = new CampoEtiquetado("nombres");
        CampoEtiquetado apellidos = new CampoEtiquetado("apellidos");
        this.seccionCamposDeBusqueda = new Bloque(nombres,apellidos);
        this.add(this.seccionCamposDeBusqueda);

        JButton botonBuscar = new JButton("Buscar");
        botonBuscar.addMouseListener(eventoBotonBuscar);
        this.add(botonBuscar);

        int cantidadElementos = elementos.size();
        this.agregarElementosFormateados();
        this.add(this.seccionElementos);

        JButton botonMenu = new JButton("MENÚ");
        JButton botonModificarDato= new JButton("MODIFICAR DATO DE HUESPED SELECCIONADO");
        botonModificarDato.addMouseListener(this.eventoBotonModificarDato);
        this.agregarSeccionBotones(botonMenu,botonModificarDato);

        /* super(3,1);
        this.elementos = huespedes;
        this.eventoBotonModificarDato = eventoBotonModificar;
        //Vector<PanelConBotones> filasHuespedes = this.obtenerElementosParaSeccion();
        Vector<String> contenidoDeLista = this.obtenerInfoDeHuespedes();
        this.huespedesEncontrados = new JList(contenidoDeLista);
        this.seccionElementos = new JScrollPane(this.huespedesEncontrados);

        this.seccionCamposDeBusqueda = new Panel(4,1);
        CampoEtiquetado nombres = new CampoEtiquetado("nombres");
        CampoEtiquetado apellidos = new CampoEtiquetado("apellidos");
        JButton botonBuscar = new JButton("Buscar");
        botonBuscar.addMouseListener(eventoBotonBuscar);
        Bloque camposDeBusqueda = new Bloque(nombres,apellidos);
        this.seccionCamposDeBusqueda.agregarTituloDeSeccion("BUSCAR INFORMACIÓN DE HUESPED",25);
        this.seccionCamposDeBusqueda.agregarTituloDeSeccion("Ingrese nombres y apellidos del huesped a buscar",20);
        this.seccionCamposDeBusqueda.agregarComponentes(camposDeBusqueda);
        this.seccionCamposDeBusqueda.agregarComponentes(botonBuscar);
        this.add(this.seccionCamposDeBusqueda);
        int cantidadElementos = elementos.size();
        this.agregarElementosFormateados();
        this.add(this.seccionElementos);

        JButton botonMenu = new JButton("MENÚ");
        JButton botonModificarDato= new JButton("MODIFICAR DATO DE HUESPED SELECCIONADO");
        botonModificarDato.addMouseListener(this.eventoBotonModificarDato);
        this.agregarSeccionBotones(botonMenu,botonModificarDato);

        */
    }

    public Bloque getSeccionCamposDeBusqueda() {
        return seccionCamposDeBusqueda;
    }

    public void setSeccionCamposDeBusqueda(Bloque seccionCamposDeBusqueda) {
        this.seccionCamposDeBusqueda = seccionCamposDeBusqueda;
    }

    public JList getHuespedesEncontrados() {
        return huespedesEncontrados;
    }

    public void setHuespedesEncontrados(JList huespedesEncontrados) {
        this.huespedesEncontrados = huespedesEncontrados;
    }

    public JScrollPane getSeccionElementos() {
        return seccionElementos;
    }

    public void setSeccionElementos(JScrollPane seccionElementos) {
        this.seccionElementos = seccionElementos;
    }

    public MouseAdapter getEventoBotonModificarDato() {
        return eventoBotonModificarDato;
    }

    public void setEventoBotonModificarDato(MouseAdapter eventoBotonModificarDato) {
        this.eventoBotonModificarDato = eventoBotonModificarDato;
    }

    public Vector<String> obtenerInfoDeHuespedes(){
        Vector<String> infoDeHuespedes = new Vector<>();

        for (Huesped elemento : this.elementos) {
            String infoDeHuesped = "";
            infoDeHuesped += elemento.obtenerDato("nombres") + " ";
            infoDeHuesped += elemento.obtenerDato("apellidos") + " ";
            infoDeHuesped += elemento.obtenerDato("nacionalidad") + " ";
            infoDeHuesped += elemento.obtenerDato("numeroDeDocumento");
            infoDeHuespedes.add(infoDeHuesped);
        }
        return infoDeHuespedes;
    }

    public void actualizarLista(Lista<Huesped> huespedes){
        this.elementos = huespedes;
        Vector<String> contenidoDeLista = this.obtenerInfoDeHuespedes();
        this.huespedesEncontrados.removeAll();
        this.huespedesEncontrados.setListData(contenidoDeLista);
    }

    public void agregarElementosFormateados() {
        for (PanelConBotones filaHuesped : this.obtenerElementosParaSeccion()) {
            this.seccionElementos.add(filaHuesped);
        }
    }
/*
    public void agregarEventoAHuespedes(MouseAdapter evento){
        for (Component component : this.seccionElementos.getComponents()) {
            FilaHuesped fila = (FilaHuesped) component;
            fila.agregarEventoABotonModificar(evento);
        }
    }
*/

    public Vector<PanelConBotones> obtenerElementosParaSeccion(){
        Vector<PanelConBotones> filas = this.crearElementosParaSeccion();
        return filas;
    }


    public Vector<PanelConBotones> crearElementosParaSeccion(){
        Vector<PanelConBotones> filasConHuespedes = new Vector<>();

        for (Huesped elemento : this.elementos) {
            FilaHuesped filaHuesped = new FilaHuesped(elemento);
            filasConHuespedes.add(filaHuesped.getPanel());
        }
         return filasConHuespedes;
    }


    public Lista<Huesped> getElementos() {
        return elementos;
    }

    public void setElementos(Lista<Huesped> elementos) {
        this.elementos = elementos;
    }

    public String obtenerDatoSegunLabel(String labelName){
        String textoIngresado = this.seccionCamposDeBusqueda.obtenerTextoSegunLabel(labelName);
        return textoIngresado;
    }

    public void limpiarCampos(){
        for (Component component : this.seccionCamposDeBusqueda.getComponents()) {
            CampoEtiquetado c = (CampoEtiquetado) component;
            c.setValorACampoDeTexto("");
        }
    }

    /*
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();
        CampoEtiquetado c1 = (CampoEtiquetado) this.seccionCamposDeBusqueda.getComponent(0);
        String nombresIngresados = c1.obtenerTextoIngresado();
        datos.add(new Dato("nombresIngresados",nombresIngresados));

        CampoEtiquetado c2 = (CampoEtiquetado) this.seccionCamposDeBusqueda.getComponent(1);
        String apellidosIngresados = c2.obtenerTextoIngresado();
        datos.add(new Dato("apellidosIngresados",apellidosIngresados));

        return datos;
    }

     */
    /*
    public String obtenerValorIngresado(String nombreDelCampo){
        Object valor = seccionCamposDeBusqueda.obtenerValorSegunNombreDeCampo(nombreDelCampo);
        String valorStringDelCampo = (String) valor;
        return valorStringDelCampo;
    }

 */
}
