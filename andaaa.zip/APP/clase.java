import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class clase {

    public static void main(String[] args) {
        /*
        JFrame ventana = new JFrame();
        JTextField txt = new JTextField();
        ventana.setSize(200,300);
        ventana.setLayout(new GridLayout(3,1));
        ventana.add(txt);
        JLabel eti = new JLabel();
        ventana.add(eti);
        ventana.setVisible(true);

        JButton boton = new JButton("PRESS (?)");
        ventana.add(boton);
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                eti.setText(txt.getText());
            }
        });

        JFrame ventana = new JFrame();
        ventana.setSize(1000,1000);
        ventana.setLayout(new GridLayout(2,1));
        ventana.setVisible(true);



        formulario.setVisible(true);


         Form formulario = new Form();
         formulario.setVisible(true);
         formulario.setSize(1000,1000);


        String fecha = "2020-01-01";
        String anio = fecha.substring(0,3);
        System.out.println(anio);
        String mes = fecha.substring(4,5);
        System.out.println(mes);
        String dia = fecha.substring(6,7);
        System.out.println(dia);

         */

        ArrayList<String> palabrasSeparadas = new ArrayList<>();
        String palabras = "a b cc";
        String unaPalabra = "";

        if(palabras.length() != 0) {
            for (int i = 0; i < palabras.length(); i++) {
                if (palabras.charAt(i) != ' '){
                    unaPalabra += palabras.charAt(i);
                } else {
                    palabrasSeparadas.add(unaPalabra);
                    unaPalabra = "";
                }

                if ( i == palabras.length()-1 &&
                        palabras.charAt(i) != ' '){
                    palabrasSeparadas.add(unaPalabra);
                }
            }
        }else{
            unaPalabra = "";
            palabrasSeparadas.add(unaPalabra);
        }

        System.out.println(unaPalabra);
        System.out.println(palabrasSeparadas);

        String formatoParaConsulta = "";

        for (String string : palabrasSeparadas) {
            formatoParaConsulta += "\"%"+ string + "%\" or ";
        }

        System.out.println(formatoParaConsulta);
        int size = formatoParaConsulta.length();
        formatoParaConsulta = formatoParaConsulta.substring(0,size-4);
        System.out.println(formatoParaConsulta);

    }

}
