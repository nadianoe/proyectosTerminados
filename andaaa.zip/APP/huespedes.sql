CREATE DATABASE atahualpaHostel;

use atahulpaHostel;

create table huespedes (id bigint, nombres varchar(200),apellidos varchar(200),
nacionalidad varchar(200),fechaDeNacimiento date, lugar varchar(200),
tipoDeDocumento varchar(200),numeroDeDocumento bigint,domicilio varchar(200),
ciudad varchar(200),tipoDeLugar varchar(200),
nombreDelLugar varchar(200), pais varchar(200), telefono bigint, email varchar(200),
 obraSocial varchar(200),
direccionObraSocial varchar(200), telefonoObraSocial bigint,
 trabajoEn varchar(200), empresa varchar(200),
estudioEn varchar(200), carrera varchar(200), realizoCursoDe varchar(200),
cursoEn varchar(200),
fechaDesde date, fechaHasta date);









































