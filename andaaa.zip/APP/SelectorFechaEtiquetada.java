
import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.util.HashMap;
import java.util.Vector;

public class SelectorFechaEtiquetada extends Panel {

    private String nombreDeCampo;
    private JLabel etiqueta;
    private SelectorFecha fecha;

    public SelectorFechaEtiquetada(String nombre) {
        super(1, 2);
        this.setLayout(null);
        this.setName(nombre);
        this.nombreDeCampo = nombre;
        this.etiqueta = new JLabel();
        this.etiqueta.setText(this.darFormatoDeEtiqueta(nombre));
        this.fecha = new SelectorFecha(nombre);
        this.add(etiqueta);
        this.add(fecha);

        this.etiqueta.setFont(new Font("Arial", Font.PLAIN, 15));
        this.etiqueta.setSize(200, 20);
        this.etiqueta.setLocation(50, 20);

        this.fecha.setFont(new Font("Arial", Font.PLAIN, 15));
        this.fecha.setSize(250, 30);
        this.fecha.setLocation(250, 20);
    }

    public JLabel getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(JLabel etiqueta) {
        this.etiqueta = etiqueta;
    }

    public SelectorFecha getFecha() {
        return fecha;
    }

    public void setFecha(SelectorFecha fecha) {
        this.fecha = fecha;
    }
/*
    @Override
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();
        Date fechaSeleccionada = this.fecha.obtenerFecha();
        Dato dato = new Dato(this.nombreDeCampo,fechaSeleccionada);
        datos.add(dato);
        return datos;
    }
*/

    @Override
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();
        Fecha fechaSeleccionada = this.fecha.obtenerFecha();
        String fecha = fechaSeleccionada.toString();
        Dato dato = new Dato(this.nombreDeCampo, fecha);
        datos.add(dato);
        return datos;
    }

    @Override
    public void setValores(Huesped huesped) {
        HashMap<String, Object> valores = huesped.getDatosPersonales();
        Object valorDeSelectorRecibido = valores.get(this.nombreDeCampo);
        Fecha fechaRecibida = new Fecha(valorDeSelectorRecibido.toString());
        this.fecha.setValoresDeFecha(fechaRecibida);
    }

    @Override
    public Lista<String> getNombresDeCampos() {
        Lista<String> nombresDeCampo = new Lista<>();
        nombresDeCampo.add(this.nombreDeCampo);
        return nombresDeCampo;
    }
}
