
public class Dato {

    private String nombreDeCampo;
    private Object valor;

    public Dato(String nombreDeCampo, Object valor) {
        this.nombreDeCampo = nombreDeCampo;
        this.valor = valor;
    }

    public String getNombreDeCampo() {
        return nombreDeCampo;
    }

    public void setNombreDeCampo(String nombreDeCampo) {
        this.nombreDeCampo = nombreDeCampo;
    }

    public Object getValor() {
        return valor;
    }

    public void setValor(Object valor) {
        this.valor = valor;
    }
}
