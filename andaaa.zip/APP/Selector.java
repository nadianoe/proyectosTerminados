
import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Vector;

public class Selector extends Panel {

    private JComboBox selector;
    private Vector<Object> opciones;

    public Selector(String nombre, String... opciones){
        super(1,1);
        this.setName(nombre);
        this.selector = new JComboBox();
        this.opciones = new Vector<>(Arrays.asList(opciones));
        setearConOpcionElegida();
        this.setVisible(true);
        this.add(selector);
    }

    public Selector(String nombre, Vector<Object> opciones){
        super(1,1);
        this.setName(nombre);
        this.selector = new JComboBox();
        this.opciones = opciones;
        this.setearConOpcionElegida();
        this.setVisible(true);
        this.add(selector);

    }

    public Object getValorSeleccionado(){
        Object valorSeleccionado = new Object();
        valorSeleccionado = this.selector.getSelectedItem();
        return valorSeleccionado;
    }

    public void setearConOpcionElegida(){
        selector.setModel(new DefaultComboBoxModel(this.opciones));
        String opcionElegidaPorUsuario = selector.getSelectedItem().toString();
        selector.setSelectedItem(opcionElegidaPorUsuario);
    }

    public Object obtenerValorElegido(){
        Object valor = this.selector.getSelectedItem();
        return valor;
    }

    public static Vector<Object> paises(){
        String naciones = "Afganistán," +
                "Albania," +
                "Alemania," +
                "Andorra," +
                "Angola," +
                "Antigua y Barbuda," +
                "Arabia Saudita," +
                "Argelia," +
                "Argentina," +
                "Armenia," +
                "Australia," +
                "Austria," +
                "Azerbaiyán," +
                "Bahamas," +
                "Bangladés," +
                "Barbados," +
                "Baréin," +
                "Bélgica," +
                "Belice," +
                "Benín," +
                "Bielorrusia," +
                "Birmania," +
                "Bolivia," +
                "Bosnia y Herzegovina," +
                "Botsuana," +
                "Brasil," +
                "Brunéi," +
                "Bulgaria," +
                "Burkina Faso," +
                "Burundi," +
                "Bután," +
                "Cabo Verde," +
                "Camboya," +
                "Camerún," +
                "Canadá," +
                "Catar," +
                "Chad," +
                "Chile," +
                "China," +
                "Chipre," +
                "Ciudad del Vaticano," +
                "Colombia," +
                "Comoras," +
                "Corea del Norte," +
                "Corea del Sur," +
                "Costa de Marfil," +
                "Costa Rica," +
                "Croacia," +
                "Cuba," +
                "Dinamarca," +
                "Dominica," +
                "Ecuador," +
                "Egipto," +
                "El Salvador," +
                "Emiratos Árabes Unidos," +
                "Eritrea," +
                "Eslovaquia," +
                "Eslovenia," +
                "España," +
                "Estados Unidos," +
                "Estonia," +
                "Etiopía," +
                "Filipinas," +
                "Finlandia," +
                "Fiyi," +
                "Francia," +
                "Gabón," +
                "Gambia," +
                "Georgia," +
                "Ghana," +
                "Granada," +
                "Grecia," +
                "Guatemala," +
                "Guyana," +
                "Guinea," +
                "Guinea ecuatorial," +
                "Guinea-Bisáu," +
                "Haití," +
                "Honduras," +
                "Hungría," +
                "India," +
                "Indonesia," +
                "Irak," +
                "Irán," +
                "Irlanda," +
                "Islandia," +
                "Islas Marshall," +
                "Islas Salomón," +
                "Israel," +
                "Italia," +
                "Jamaica," +
                "Japón," +
                "Jordania," +
                "Kazajistán," +
                "Kenia," +
                "Kirguistán," +
                "Kiribati," +
                "Kuwait," +
                "Laos," +
                "Lesoto," +
                "Letonia," +
                "Líbano," +
                "Liberia," +
                "Libia," +
                "Liechtenstein," +
                "Lituania," +
                "Luxemburgo," +
                "Macedonia del Norte," +
                "Madagascar," +
                "Malasia," +
                "Malaui," +
                "Maldivas," +
                "Malí," +
                "Malta," +
                "Marruecos," +
                "Mauricio," +
                "Mauritania," +
                "México," +
                "Micronesia," +
                "Moldavia," +
                "Mónaco," +
                "Mongolia," +
                "Montenegro," +
                "Mozambique," +
                "Namibia," +
                "Nauru," +
                "Nepal," +
                "Nicaragua," +
                "Níger," +
                "Nigeria," +
                "Noruega," +
                "Nueva Zelanda," +
                "Omán," +
                "Países Bajos," +
                "Pakistán," +
                "Palaos," +
                "Panamá," +
                "Papúa Nueva Guinea," +
                "Paraguay," +
                "Perú," +
                "Polonia," +
                "Portugal," +
                "Reino Unido," +
                "República Centroafricana," +
                "República Checa," +
                "República del Congo," +
                "República Democrática del Congo," +
                "República Dominicana," +
                "Ruanda," +
                "Rumanía," +
                "Rusia," +
                "Samoa," +
                "San Cristóbal y Nieves," +
                "San Marino," +
                "San Vicente y las Granadinas," +
                "Santa Lucía," +
                "Santo Tomé y Príncipe," +
                "Senegal," +
                "Serbia," +
                "Seychelles," +
                "Sierra Leona," +
                "Singapur," +
                "Siria," +
                "Somalia," +
                "Sri Lanka," +
                "Suazilandia," +
                "Sudáfrica," +
                "Sudán," +
                "Sudán del Sur," +
                "Suecia," +
                "Suiza," +
                "Surinam," +
                "Tailandia," +
                "Tanzania," +
                "Tayikistán," +
                "Timor Oriental," +
                "Togo," +
                "Tonga," +
                "Trinidad y Tobago," +
                "Túnez," +
                "Turkmenistán," +
                "Turquía," +
                "Tuvalu," +
                "Ucrania," +
                "Uganda," +
                "Uruguay," +
                "Uzbekistán," +
                "Vanuatu," +
                "Venezuela," +
                "Vietnam," +
                "Yemen," +
                "Yibuti," +
                "Zambia," +
                "Zimbabue,";

        Vector<Object> nacionalidades = new Vector<>();
        String pais = "";

        for (int i = 0; i < naciones.length(); i++) {
            if (naciones.charAt(i) != ','){
                pais = pais + naciones.charAt(i);
            }else{
                nacionalidades.add(pais);
                pais = "";
            }
        }

        return nacionalidades;
    }

    public void setSelectedItem(Object value){
        this.selector.setSelectedItem(value);
    }


}
