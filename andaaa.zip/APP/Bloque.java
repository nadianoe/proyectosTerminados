

import java.awt.*;

public class Bloque extends Panel {

    private Component elemento1;
    private Component elemento2;

    public Bloque(Component elemento1, Component elemento2) {
        super(1,2);
        this.elemento1 = elemento1;
        this.elemento2 = elemento2;
        this.agregarComponentes(elemento1,elemento2);
        this.setVisible(true);
        this.add(elemento1);
        this.add(elemento2);

    }

    public Bloque() {
        super(1,2);
        this.elemento1 = new CampoEtiquetado("a");
        this.elemento2 = new CampoEtiquetado("a");
    }

    public Bloque(CampoEtiquetado elemento1) {
        super(1,1);
        this.elemento1 = elemento1;
        this.agregarComponentes(elemento1);
    }

    public void agregarComponentes(Component... componentes){
        for (Component componente : componentes) {
            this.add(componente);
        }
    }
    
    public String obtenerTextoSegunLabel(String nombreDeLabel){
		String valorBuscado = "";
		if(elemento1.getName().equals(nombreDeLabel)){
            CampoEtiquetado c = (CampoEtiquetado) elemento1;
			valorBuscado = c.obtenerTextoIngresado();
		}else if(elemento2.getName().equals(nombreDeLabel)){
		    CampoEtiquetado c = (CampoEtiquetado) elemento2;
		    valorBuscado = c.obtenerTextoIngresado();
        }
		return valorBuscado;
	}

	public void setTextToComponents(String nombreDeComponente, String textoASetear){
        if(elemento1.getName().equals(nombreDeComponente)){
            CampoEtiquetado c = (CampoEtiquetado) elemento1;
            c.setValorACampoDeTexto(textoASetear);
        }else if(elemento2.getName().equals(nombreDeComponente)){
            CampoEtiquetado c = (CampoEtiquetado) elemento2;
            c.setValorACampoDeTexto(textoASetear);
        }
    }
}
