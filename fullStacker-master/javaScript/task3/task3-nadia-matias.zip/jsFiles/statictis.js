let statictis = {

                            "numeroDeRepresentantes": {
                                "democratas": 0,
                                "republicans": 0,
                                "independients": 0,
                                "total": 0
                            },

                            "votesWithParty": {
                                "democratas": 0,
                                "republicans": 0,
                                "independients": 0,
                                "total": 0
                            }
                        };

