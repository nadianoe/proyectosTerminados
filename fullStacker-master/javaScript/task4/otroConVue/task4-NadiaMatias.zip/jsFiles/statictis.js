let statictis = {

        "nroReps": {
            "democratas": 0,
            "republicans": 0,
            "independients": 0,
            "total": 0
        },

        "votesPrc": {
            "democratas": 0,
            "republicans": 0,
            "independients": 0,
            "total": 0
        },

        "selectedMembers": {
            "leastEngaged":[],
            "mostEngaged":[],
            "leastLoyal":[],
            "mostLoyal":[]
        }
    };



