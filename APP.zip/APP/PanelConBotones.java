import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.*;

public class PanelConBotones extends Panel{

    private Bloque seccionBotones;

    PanelConBotones(int filas, int columnas){
        super(filas,columnas);
        this.seccionBotones = new Bloque();
    }

    public Bloque getSeccionBotones() {
        return seccionBotones;
    }

    public void setSeccionBotones(Bloque seccionBotones) {
        this.seccionBotones = seccionBotones;
    }

    public void agregarSeccionBotones(JButton... botones){
        for (JButton boton : botones) {
            this.seccionBotones.agregarComponentes(boton);
        }
        this.add(this.seccionBotones);
    }

    public void agregarEventoABoton(String textoDeBoton, MouseAdapter evento){
        for (Component component : this.seccionBotones.getComponents()) {
            JButton boton = (JButton) component;
            if (boton.getText().equals(textoDeBoton)){
                boton.addMouseListener(evento);
            }
        }
    }



}
