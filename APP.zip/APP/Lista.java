
import javax.swing.*;
import java.util.ArrayList;
import java.util.Vector;

public class Lista<E> extends ArrayList<E> {

    public void add(E... elementos){
        for (E elemento : elementos) {
            this.add(elemento);
        }
    }

    public void agregarCamposEtiquetados(String... nombresDeEtiquetas){
        for (String nombreDeEtiqueta : nombresDeEtiquetas) {
            CampoEtiquetado campoNuevo = new CampoEtiquetado(nombreDeEtiqueta);
            this.add((E) campoNuevo);
        }
    }

    public void agregarSelectoresFecha(String... nombreDeCampos){
        for (String nombreDeCampo : nombreDeCampos) {
            SelectorFecha selectorFecha =  new SelectorFecha(nombreDeCampo);
            this.add((E) selectorFecha);
        }
    }


    public void agregarSelectorConOpciones(String nombre, Vector<Object> opciones){
        Selector selectorNuevo = new Selector(nombre,opciones);
        this.add((E) selectorNuevo);
    }

    public void agregarSelectorConOpciones(String nombre, String... opciones){
        Selector selectorNuevo = new Selector(nombre,opciones);
        this.add((E) selectorNuevo);
    }
/*
    public static Huesped obtenerElementoDeDato(Lista<Huesped> huespedes,String nombres,String apellidos){
        Huesped elementoBuscado = null;
        for (Huesped elemento : huespedes) {
            if (elemento.obtenerDato("nombres").equals(nombres) &&
                )

        }
        return elementoBuscado;
    }
*/

    public static void imprimirLista(Lista<Dato> datos){
        for (Dato dato : datos) {
            System.out.println("-----------------------");
            System.out.println(dato.getNombreDeCampo());
            System.out.println(dato.getValor());
            System.out.println("-----------------------");
        }
    }


}
