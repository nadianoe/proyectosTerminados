
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Vector;

public class SelectorEtiquetado extends Panel{

    private String nombeDeCampo;
    private JLabel etiqueta;
    private Selector selector;

    public SelectorEtiquetado(String nombre, Vector<Object> opciones) {
        super(1, 2);
        this.setLayout(null);
        this.nombeDeCampo = nombre;
        this.etiqueta = new JLabel();
        this.etiqueta.setText(this.darFormatoDeEtiqueta(nombre));
        this.selector = new Selector(nombre,opciones);
        this.selector.setSelectedItem(opciones.get(0));
        this.add(etiqueta);
        this.add(selector);

        this.etiqueta.setFont(new Font("Arial", Font.PLAIN, 15));
        this.etiqueta.setSize(100,20);
        this.etiqueta.setLocation(50, 20);

        this.selector.setFont(new Font("Arial", Font.PLAIN, 15));
        this.selector.setSize( 350, 30);
        this.selector.setLocation(200, 20);
    }

    public SelectorEtiquetado(String nombre, String... opciones) {
        super(1, 2);
        this.setLayout(null);
        this.nombeDeCampo = nombre;
        this.etiqueta = new JLabel();
        this.selector = new Selector(nombre,opciones);
        this.add(etiqueta);
        this.add(selector);

        this.etiqueta.setFont(new Font("Arial", Font.PLAIN, 15));
        this.etiqueta.setSize(100,20);
        this.etiqueta.setLocation(50, 20);

        this.selector.setFont(new Font("Arial", Font.PLAIN, 15));
        this.selector.setSize( 250, 30);
        this.selector.setLocation(250, 20);
    }

    public JLabel getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(JLabel etiqueta) {
        this.etiqueta = etiqueta;
    }

    public Selector getSelector() {
        return selector;
    }

    public void setSelector(Selector selector) {
        this.selector = selector;
    }

    @Override
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();
        String itemSeleccionado = this.selector.getValorSeleccionado().toString();
        Dato dato = new Dato(this.nombeDeCampo,itemSeleccionado);
        datos.add(dato);
        return datos;
    }

    @Override
    public void setValores(Huesped huesped) {
        HashMap<String,Object> valores = huesped.getDatosPersonales();

        Object valorDeSelectorRecibido = valores.get(this.nombeDeCampo);
        this.selector.setSelectedItem(valorDeSelectorRecibido);
    }

    @Override
    public Lista<String> getNombresDeCampos() {
        Lista<String> nombresDeCampo = new Lista<>();
        nombresDeCampo.add(this.selector.getName());
        return nombresDeCampo;
    }

}
