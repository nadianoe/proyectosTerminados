import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.util.HashMap;

public class FilaHuesped{

    private Huesped huesped;
    private PanelConBotones panel;

    public FilaHuesped(Huesped huesped) {
        this.panel = new PanelConBotones(1,3);
        this.huesped = huesped;

    //    long numDeDocumento = (long) huesped.obtenerDato("numeroDeDocumento");
        String nombres = (String) this.huesped.obtenerDato("nombres");
        JLabel labelNombres = new JLabel(nombres);

        String apellidos = (String) this.huesped.obtenerDato("apellidos");
        JLabel labelApellidos = new JLabel(apellidos);

        this.panel.agregarComponentes(labelNombres,labelApellidos);

        JButton botonModificar = new JButton("Modificar datos");
        this.panel.agregarSeccionBotones(botonModificar);

    }

    public void agregarEventoABotonModificar(MouseAdapter evento){
        this.panel.getSeccionBotones().getComponent(0).addMouseListener(evento);
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }

    public void setHuesped(HashMap<String,Object> valores){
        this.huesped.setDatosPersonales(valores);
    }

    public PanelConBotones getPanel() {
        return panel;
    }

    public void setPanel(PanelConBotones panel) {
        this.panel = panel;
    }
}
