import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.Vector;

public class Buscador extends PanelConBotones {

    //private Form seccionCamposDeBusqueda;
    private Panel seccionCamposDeBusqueda;
    private Lista<Huesped> elementos;
    private JList huespedesEncontrados;
    private JScrollPane seccionElementos;
    private MouseAdapter eventoBotonModificarDato;

    public Buscador(Lista<Huesped> huespedes,MouseAdapter eventoBotonModificar){
        super(3,1);
        this.elementos = huespedes;
        this.eventoBotonModificarDato = eventoBotonModificar;
        //Vector<PanelConBotones> filasHuespedes = this.obtenerElementosParaSeccion();
        Vector<String> contenidoDeLista = this.obtenerInfoDeHuespedes();
        this.huespedesEncontrados = new JList(contenidoDeLista);
        this.seccionElementos = new JScrollPane(this.huespedesEncontrados);
        this.seccionCamposDeBusqueda = new Panel(3,1);
        CampoEtiquetado nombres = new CampoEtiquetado("nombres");
        CampoEtiquetado apellidos = new CampoEtiquetado("apellidos");
        Bloque camposDeBusqueda = new Bloque(nombres,apellidos);
        this.seccionCamposDeBusqueda.agregarTituloDeSeccion("BUSCAR INFORMACIÓN DE HUESPED",25);
        this.seccionCamposDeBusqueda.agregarTituloDeSeccion("Ingrese nombres y apellidos del huesped a buscar",20);
        this.seccionCamposDeBusqueda.agregarComponentes(camposDeBusqueda);
        this.add(this.seccionCamposDeBusqueda);
        int cantidadElementos = elementos.size();
        this.agregarElementosFormateados();
        this.add(this.seccionElementos);

        JButton botonMenu = new JButton("MENÚ");
        JButton botonModificarDato= new JButton("MODIFICAR DATO DE HUESPED");
        botonModificarDato.addMouseListener(this.eventoBotonModificarDato);
        this.agregarSeccionBotones(botonMenu,botonModificarDato);
    }

    public Panel getSeccionCamposDeBusqueda() {
        return seccionCamposDeBusqueda;
    }

    public void setSeccionCamposDeBusqueda(Panel seccionCamposDeBusqueda) {
        this.seccionCamposDeBusqueda = seccionCamposDeBusqueda;
    }

    public JList getHuespedesEncontrados() {
        return huespedesEncontrados;
    }

    public void setHuespedesEncontrados(JList huespedesEncontrados) {
        this.huespedesEncontrados = huespedesEncontrados;
    }

    public JScrollPane getSeccionElementos() {
        return seccionElementos;
    }

    public void setSeccionElementos(JScrollPane seccionElementos) {
        this.seccionElementos = seccionElementos;
    }

    public MouseAdapter getEventoBotonModificarDato() {
        return eventoBotonModificarDato;
    }

    public void setEventoBotonModificarDato(MouseAdapter eventoBotonModificarDato) {
        this.eventoBotonModificarDato = eventoBotonModificarDato;
    }

    public Vector<String> obtenerInfoDeHuespedes(){
        Vector<String> infoDeHuespedes = new Vector<>();

        for (Huesped elemento : this.elementos) {
            String infoDeHuesped = "";
            infoDeHuesped += elemento.obtenerDato("nombres") + " ";
            infoDeHuesped += elemento.obtenerDato("apellidos") + " ";
            infoDeHuesped += elemento.obtenerDato("nacionalidad") + " ";
            infoDeHuesped += elemento.obtenerDato("numeroDeDocumento");
            infoDeHuespedes.add(infoDeHuesped);
        }
        return infoDeHuespedes;
    }

    public void agregarElementosFormateados() {
        for (PanelConBotones filaHuesped : this.obtenerElementosParaSeccion()) {
            this.seccionElementos.add(filaHuesped);
        }
    }
/*
    public void agregarEventoAHuespedes(MouseAdapter evento){
        for (Component component : this.seccionElementos.getComponents()) {
            FilaHuesped fila = (FilaHuesped) component;
            fila.agregarEventoABotonModificar(evento);
        }
    }
*/

    public Vector<PanelConBotones> obtenerElementosParaSeccion(){
        Vector<PanelConBotones> filas = this.crearElementosParaSeccion();
        return filas;
    }


    public Vector<PanelConBotones> crearElementosParaSeccion(){
        Vector<PanelConBotones> filasConHuespedes = new Vector<>();

        for (Huesped elemento : this.elementos) {
            FilaHuesped filaHuesped = new FilaHuesped(elemento);
            filasConHuespedes.add(filaHuesped.getPanel());
        }
         return filasConHuespedes;
    }


    public Lista<Huesped> getElementos() {
        return elementos;
    }

    public void setElementos(Lista<Huesped> elementos) {
        this.elementos = elementos;
    }



/*
    public String obtenerValorIngresado(String nombreDelCampo){
        Object valor = seccionCamposDeBusqueda.obtenerValorSegunNombreDeCampo(nombreDelCampo);
        String valorStringDelCampo = (String) valor;
        return valorStringDelCampo;
    }

 */
}
