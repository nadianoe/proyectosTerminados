

import java.awt.*;

public class Bloque extends Panel {

    private Component elemento1;
    private Component elemento2;

    public Bloque(Component elemento1, Component elemento2) {
        super(1,2);
        this.elemento1 = elemento1;
        this.elemento2 = elemento2;
        this.agregarComponentes(elemento1,elemento2);
        this.setVisible(true);
        this.add(elemento1);
        this.add(elemento2);

    }

    public Bloque() {
        super(1,2);
        this.elemento1 = new Panel();
        this.elemento2 = new Panel();
    }

    public Bloque(Component elemento1) {
        super(1,1);
        this.elemento1 = elemento1;
        this.agregarComponentes(elemento1);
    }

    public void agregarComponentes(Component... componentes){
        for (Component componente : componentes) {
            this.add(componente);
        }
    }
}
