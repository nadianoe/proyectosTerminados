import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class clase {

    public static void main(String[] args) {
        /*
        JFrame ventana = new JFrame();
        JTextField txt = new JTextField();
        ventana.setSize(200,300);
        ventana.setLayout(new GridLayout(3,1));
        ventana.add(txt);
        JLabel eti = new JLabel();
        ventana.add(eti);
        ventana.setVisible(true);

        JButton boton = new JButton("PRESS (?)");
        ventana.add(boton);
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                eti.setText(txt.getText());
            }
        });

        JFrame ventana = new JFrame();
        ventana.setSize(1000,1000);
        ventana.setLayout(new GridLayout(2,1));
        ventana.setVisible(true);



        formulario.setVisible(true);


         Form formulario = new Form();
         formulario.setVisible(true);
         formulario.setSize(1000,1000);
         */

        String fecha = "2020-01-01";
        String anio = fecha.substring(0,3);
        System.out.println(anio);
        String mes = fecha.substring(4,5);
        System.out.println(mes);
        String dia = fecha.substring(6,7);
        System.out.println(dia);


    }



}
