
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Vector;

public class SelectorConCampo extends Panel{

    private String nombreDeCampo;
    private Selector selector;
    private JTextField campoDeTexto;

    public SelectorConCampo(String nombreDeSelector,String nombreDeCampo,String... opciones) {
        super(1,2);
        this.setLayout(null);
        this.nombreDeCampo = nombreDeCampo;
        this.selector = new Selector(nombreDeSelector,opciones);
        this.selector.setSelectedItem(opciones[0]);
        this.campoDeTexto = new JTextField();
        this.add(selector);
        this.add(campoDeTexto);

        this.campoDeTexto.setFont(new Font("Arial", Font.PLAIN, 15));
        this.campoDeTexto.setSize(350,20);
        this.campoDeTexto.setLocation(200, 20);

        this.selector.setFont(new Font("Arial", Font.PLAIN, 15));
        this.selector.setSize(130, 30);
        this.selector.setLocation(50, 20);
    }

    public SelectorConCampo(String nombre, Vector<Object> opciones) {
        super(1,2);
        this.setLayout(null);
        this.setName(nombre);
        this.selector = new Selector(nombre,opciones);
        this.campoDeTexto = new JTextField();
        this.add(selector);
        this.add(campoDeTexto);

        this.campoDeTexto.setFont(new Font("Arial", Font.PLAIN, 15));
        this.campoDeTexto.setSize(250,20);
        this.campoDeTexto.setLocation(250, 20);

        this.selector.setFont(new Font("Arial", Font.PLAIN, 15));
        this.selector.setSize(100, 30);
        this.selector.setLocation(50, 20);
    }

    @Override
    public Lista<Dato> obtenerDatos() {
        Lista<Dato> datos = new Lista<>();

        String nombreDeSelector = this.selector.getName();
        String itemSeleccionado = this.selector.getValorSeleccionado().toString();
        Dato datoDeSelector = new Dato(nombreDeSelector,itemSeleccionado);

        Object valorDeCampo = new Object();

        if (nombreDeSelector.equals("tipoDeDocumento")){
            valorDeCampo = Long.parseLong(this.campoDeTexto.getText());
        } else{
            valorDeCampo = this.campoDeTexto.getText();
        }

        Dato datoDeCampo = new Dato(this.nombreDeCampo,valorDeCampo);

        datos.add(datoDeSelector,datoDeCampo);
        return datos;
    }

    @Override
    public void setValores(Huesped huesped) {
        HashMap<String,Object> valores = huesped.getDatosPersonales();

        String nombreDeSelector = this.selector.getName();
        Object valorDeSelectorRecibido = valores.get(nombreDeSelector);
        this.selector.setSelectedItem(valorDeSelectorRecibido);

        Object valorDeCampoRecibido = valores.get(this.nombreDeCampo);
        String nuevoValor = valorDeCampoRecibido.toString();
        this.campoDeTexto.setText(nuevoValor);
    }

    @Override
    public Lista<String> getNombresDeCampos() {
        Lista<String> nombresDeCampo = new Lista<>();
        nombresDeCampo.add(this.selector.getName());
        nombresDeCampo.add(this.nombreDeCampo);
        return nombresDeCampo;
    }
}
