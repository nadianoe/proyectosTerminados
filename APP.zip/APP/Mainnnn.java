
import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.util.Calendar;

public class Mainnnn extends JFrame {
    private Form form;

    public Mainnnn(Form form) throws HeadlessException {
        this.form = form;
    }

    public Mainnnn(){
        this.setLayout(new BorderLayout());
        form = new Form();
        this.add("Center",form);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setVisible(true);
    }

    public static void main(String[] args) {

        java.util.Date coso = new Date(1,2,3);



    }
}
