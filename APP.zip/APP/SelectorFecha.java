
import java.sql.Date;
import java.util.*;

public class SelectorFecha extends Panel {

    private Selector dias;
    private Selector meses;
    private Selector anios;

    public SelectorFecha(String nombre){
        super(1,3);
        this.setName(nombre);
        Vector<Object> dias = this.obtenerVectorConNumerosDeDias();
        this.dias = new Selector("dias",dias);
        this.dias.setSelectedItem(1);
        Vector<Object> meses = this.obtenerVectorConNumerosDeMeses();
        this.meses = new Selector("meses",meses);
        this.meses.setSelectedItem(1);
        Vector<Object> anios = this.obtenerVectorConNumerosDeAnios();
        this.anios = new Selector("anios",anios);
        this.anios.setSelectedItem(Fecha.ANIO_ACTUAL);
        this.setVisible(true);
        this.add(this.dias);
        this.add(this.meses);
        this.add(this.anios);
    }

    public int obtenerValorDeDiaElegido(){
        int diaElegido = (int) dias.obtenerValorElegido();
        return diaElegido;
    }

    public int obtenerValorDeMesElegido(){
        int mesElegido = (int) meses.obtenerValorElegido();
        return mesElegido;
    }

    public int obtenerValorDeAnioElegido(){
        int anioElegido = (int) anios.obtenerValorElegido();
        return anioElegido;
    }
/*
    public Fecha obtenerFecha(){
        Fecha fechaActual = new Fecha();
        fechaActual.setDia(this.obtenerValorDeDiaElegido());
        fechaActual.setMes(this.obtenerValorDeMesElegido());
        fechaActual.setAnio(this.obtenerValorDeAnioElegido());
        return fechaActual;
    }
*/

    public Vector<Object> obtenerVectorConNumerosDeDias(){
        Vector<Object> opcionesDeDias = new Vector<>();
        for (int i = 1; i <= 31; i++) {
            opcionesDeDias.add(i);
        }
        return opcionesDeDias;
    }

    public Vector<Object> obtenerVectorConNumerosDeMeses(){
        Vector<Object> opcionesDeMeses = new Vector<>();
        for (int i = 1; i <= 12; i++) {
            opcionesDeMeses.add(i);
        }
        return opcionesDeMeses;
    }

    public Vector<Object> obtenerVectorConNumerosDeAnios(){
        Vector<Object> opcionesDeAnios = new Vector<>();
        int anioActual = Fecha.ANIO_ACTUAL;

        for (int i = anioActual; i >= 1900 ; i--) {
            opcionesDeAnios.add(i);
        }

        return opcionesDeAnios;
    }

    public Selector getDias() {
        return dias;
    }

    public void setDias(Selector dias) {
        this.dias = dias;
    }

    public Selector getMeses() {
        return meses;
    }

    public void setMeses(Selector meses) {
        this.meses = meses;
    }

    public Selector getAnios() {
        return anios;
    }

    public void setAnios(Selector anios) {
        this.anios = anios;
    }

    public Fecha obtenerFecha(){
        int dia = (int) this.dias.getValorSeleccionado();
        int mes = (int) this.meses.getValorSeleccionado();
        int anio = (int) this.anios.getValorSeleccionado();
        //Date fechaSeleccionada = new java.sql.Date(anio,mes,dia);
        Fecha fechaSeleccionada = new Fecha(dia,mes,anio);
        return fechaSeleccionada;
    }

    public void setValoresDeFecha(Fecha fecha){
        this.anios.setSelectedItem(fecha.getAnio());
        this.meses.setSelectedItem(fecha.getMes());
        this.dias.setSelectedItem(fecha.getDia());
    }

}
