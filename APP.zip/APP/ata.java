
import java.sql.*;
import java.util.HashMap;

public class ata {

		private Connection con;

public void ejecutarConsulta(Connection con) {
         
        try {

           String SQL = "SELECT * FROM huespedes";
           Statement stmt = con.createStatement();
           ResultSet rs = stmt.executeQuery(SQL);
        
           while (rs.next()) {

           	/*
           HashMap<String,Object> datos = new HashMap<>();
               
           String nombres = rs.getString("nombres");
           datos.put(nombres,nombres);
           
           String apellidos = rs.getString("apellidos");
           datos.put(apellidos,apellidos);
           
           String nacionalidad = rs.getString("nacionalidad");
           datos.put(nacionalidad,nacionalidad);
           
           Date fechaDeNacimiento = rs.getDate("fechaDeNacimiento");
           datos.put(
           String lugar = rs.getString("lugar");
           String tipoDeDocumento = rs.getString("tipoDeDocumento");
           int numeroDeDocumento = rs.getInt("numeroDeDocumento");
           String domicilio = rs.getString("domicilio");
           String ciudad = rs.getString("ciudad");
           String tipoDeLugar = rs.getString("tipoDeLugar");
           String nombreDelLugar = rs.getString("nombreDelLugar");
           String pais = rs.getString("pais");
           int telefono = rs.getInt("telefono");
           String email = rs.getString("email");
           String obraSocial = rs.getString("obraSocial");
           String direccionObraSocial = rs.getString("direccionObraSocial");
           int telefonoObraSocial = rs.getInt("telefonoObraSocial");
           String trabajoEn = rs.getString("trabajoEn");
           String empresa = rs.getString("empresa");
           String estudioEn = rs.getString("estudioEn");
           String carrera = rs.getString("carrera");
           String realizoCursoDe = rs.getString("realizoCursoDe");
           String cursoEn = rs.getString("cursoEn");
           Date hospedajeDesde = rs.getDate("desde");
           Date hospedajeHaste = rs.getDate("hasta");
		*/

           }
          
          rs.close();
          stmt.close();

        }
        catch (Exception e) {
          e.printStackTrace();
        }
    }
        
	public void consultarPorNombre(String nombre) throws SQLException {

		String SQL = "SELECT * FROM huespedes WHERE Name = ? ";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(SQL);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt.setString(1, "nombres");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ResultSet rs = pstmt.executeQuery();

	}

	public void consultarPorNombreYApellido(String nombres,String apellidos) {

		String SQL = "SELECT * FROM huespedes WHERE Name = ? ";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(SQL);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt.setString(1, "nombres");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			ResultSet rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void actualizarDatos() throws SQLException {

		String SQL = "INSERT INTO huespedes (Col2, Col3) VALUES ('1', 2)";
		Statement stmt = con.createStatement();
		int count = stmt.executeUpdate(SQL);
		System.out.println("filas afectadas: " + count);
		stmt.close();

	}


	// metodo para form:
	public void setFormConValores(HashMap<String,Object> valores){

	}

}