import java.util.HashMap;

public class Huesped {

    private HashMap<String,Object> datosPersonales;

    public Huesped() {
        this.datosPersonales = new HashMap<>();
    }


    public HashMap<String, Object> getDatosPersonales() {
        return datosPersonales;
    }

    public void setDatosPersonales(HashMap<String, Object> datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public Object obtenerDato(String nombreDeCampo){
        Object datoBuscado = this.datosPersonales.get(nombreDeCampo);
        return datoBuscado;
    }


}
